# HalalBox

A free halal food checker for Muslims living in or visiting Japan. Paste an ingredient list (Japanese or English) and HalalBox flags pork, alcohol, gelatin, enzymes and other ingredients that need checking, with a plain-English reason for each.

HalalBox is a reading aid, not certification. It never labels a product "verified halal" unless the user confirms a halal certification mark on that exact product.

## Result categories

- **Verified halal**: the user confirmed a certification mark on the specific product
- **Needs checking**: one or more ingredients need a source or process check
- **Contains a flagged prohibited ingredient**: conflicts with common halal criteria
- **Insufficient information**: cannot be assessed reliably

## Features

- Ingredient checker with Japanese and English matching
- Barcode scanner (browser BarcodeDetector, with manual entry fallback)
- Searchable ingredient guide
- Works offline-friendly as a single static file, no tracking, no sign-up

## Run locally

Open `index.html` in a browser. No build step.

## Deploy free

**GitHub Pages:** Settings, then Pages, then deploy from branch `main` / root.
**Cloudflare Pages:** connect the repo, framework preset "None", build command empty, output directory `/`.

## Contributing

The ingredient dictionary is the `D` array in `index.html`. To add or correct an entry, open a pull request with the ingredient (Japanese and English), whether it should be flagged or checked, and a source for the reasoning. Halal standards differ between scholars and certifiers, so entries should explain the disagreement rather than hide it.

## Roadmap

- Automatic product lookup from [Open Food Facts](https://world.openfoodfacts.org/) (attribution required under their ODbL licence)
- Search by product name
- Bengali and more languages
- Reviewed community submissions

## Licence

MIT. See `LICENSE`.
